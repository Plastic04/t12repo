function Erettsegi(pontok) {
    var osszpontszam = pontok.reduce(function (acc, curr) { return acc + curr; }, 0);
    var jegy;
    if (osszpontszam >= 0 && osszpontszam <= 39) {
        jegy = 1;
    }
    else if (osszpontszam >= 40 && osszpontszam <= 59) {
        jegy = 2;
    }
    else if (osszpontszam >= 60 && osszpontszam <= 79) {
        jegy = 3;
    }
    else if (osszpontszam >= 80 && osszpontszam <= 119) {
        jegy = 4;
    }
    else if (osszpontszam >= 120 && osszpontszam <= 150) {
        jegy = 5;
    }
    else {
        throw new Error('Érvénytelen pontszámok');
    }
    return [osszpontszam, jegy];
}
