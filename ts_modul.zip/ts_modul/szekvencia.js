function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
