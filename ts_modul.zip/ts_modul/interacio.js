function OszthatoSzamok(oszto, vizsgaltTomb) {
    var oszthatoSzamokSzama = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % oszto === 0) {
            oszthatoSzamokSzama++;
        }
    }
    return oszthatoSzamokSzama;
}
