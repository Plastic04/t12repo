function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
    if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
            return 3;
        } else {
            return 2;
        }
    } else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    } else {
        return 0;
    }
}