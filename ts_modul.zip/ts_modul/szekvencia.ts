function MegtettUt(sebesseg: number, ido: number): number {
  return sebesseg * ido;
}