function OszthatoSzamok(oszto: number, vizsgaltTomb: number[]): number {
    let oszthatoSzamokSzama = 0;
    
    for (let i = 0; i < vizsgaltTomb.length; i++) {
      if (vizsgaltTomb[i] % oszto === 0) {
        oszthatoSzamokSzama++;
      }
    }
    
    return oszthatoSzamokSzama;
  }