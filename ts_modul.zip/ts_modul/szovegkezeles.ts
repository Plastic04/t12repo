function LeetKod(vizsgaltSzoveg: string): string {
    let atalakitottSzoveg = '';
  
    for (let i = 0; i < vizsgaltSzoveg.length; i++) {
      const karakter = vizsgaltSzoveg[i];
  
      if (karakter === 'i' || karakter === 'I') {
        atalakitottSzoveg += '1';
      } else if (karakter === 'o' || karakter === 'O') {
        atalakitottSzoveg += '0';
      } else if (karakter === 'a' || karakter === 'A') {
        atalakitottSzoveg += '4';
      } else if (karakter === 'e' || karakter === 'E') {
        atalakitottSzoveg += '3';
      } else {
        atalakitottSzoveg += karakter;
      }
    }
  
    return atalakitottSzoveg;
  }