type ErettsegiEredmeny = [number, number]; 

function Erettsegi(pontok: number[]): ErettsegiEredmeny {
  let osszpontszam = pontok.reduce((acc, curr) => acc + curr, 0);
  let jegy: number;

  if (osszpontszam >= 0 && osszpontszam <= 39) {
    jegy = 1;
  } else if (osszpontszam >= 40 && osszpontszam <= 59) {
    jegy = 2;
  } else if (osszpontszam >= 60 && osszpontszam <= 79) {
    jegy = 3;
  } else if (osszpontszam >= 80 && osszpontszam <= 119) {
    jegy = 4;
  } else if (osszpontszam >= 120 && osszpontszam <= 150) {
    jegy = 5;
  } else {
    throw new Error('Érvénytelen pontszámok');
  }

  return [osszpontszam, jegy];
}