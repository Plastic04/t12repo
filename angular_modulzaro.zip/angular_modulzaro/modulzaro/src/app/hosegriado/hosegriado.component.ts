import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {
  elsoHomerseklet: number=0;
  masodikHomerseklet: number=0;
  harmadikHomerseklet: number=0;
  riadoSzint: string = '';
  riadoSzintLog: string[] = [];

  calculateRiadoSzint() {
    if (this.elsoHomerseklet && this.masodikHomerseklet && this.harmadikHomerseklet) {
      const atlagHomerseklet = (this.elsoHomerseklet + this.masodikHomerseklet + this.harmadikHomerseklet) / 3;

      if (atlagHomerseklet > 27) {
        this.riadoSzint = '3. szintű hőségriadó volt enredelve';
      } else if (atlagHomerseklet > 25) {
        this.riadoSzint = '2. szintű hőségriadó volt enredelve';
      } else {
        this.riadoSzint = '1. szintű hőségriadó volt enredelve';
      }
      const logEntry = `${this.elsoHomerseklet}, ${this.masodikHomerseklet} és ${this.harmadikHomerseklet} esetén ${this.riadoSzint}`;
      this.riadoSzintLog.push(logEntry);
    }
  }
}







